//Creado con Ardora - www.webardora.net
//bajo licencia Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)
//para otros usos contacte con el autor
var timeAct=360; timeIni=360; timeBon=20;
var successes=0; successesMax=8; attempts=0; attemptsMax=10;
var score=0; scoreMax=10; scoreInc=10; scoreDec=2
var typeGame=2;
var tiTime=true;
var tiTimeType=0;
var tiButtonTime=true;
var textButtonTime="Comenzar";
var tiSuccesses=true;
var tiAttempts=true;
var tiScore=true;
var startTime;
var colorBack="#FFFDFD"; colorButton="#91962F"; colorText="#000000"; colorSele="#FF8000";
var goURLNext=false; goURLRepeat=false;tiAval=false;
var scoOk=0; scoWrong=0; scoOkDo=0; scoWrongDo=0; scoMessage=""; scoPtos=10;
var fMenssage="Verdana, Geneva, sans-serif";
var fActi="Verdana, Geneva, sans-serif";
var fEnun="Verdana, Geneva, sans-serif";
var timeOnMessage=5; messageOk="Excelent."; messageTime="Game over."; messageError="Try again."; messageAttempts="Game over."; isShowMessage=false;
var urlOk=""; urlTime=""; urlError=""; urlAttempts="";
var goURLOk="_blank"; goURLTime="_blank"; goURLAttempts="_blank"; goURLError="_blank"; 
borderOk="#008000"; borderTime="#FF0000";borderError="#FF0000"; borderAttempts="#FF0000";
var imaSel=0; texSel=0;
var board=[["actividad_resources/media/1.png","actividad_resources/media/2.png","actividad_resources/media/3.jpg","actividad_resources/media/4.jpg"],["actividad_resources/media/5.jpg","actividad_resources/media/6.jpg","actividad_resources/media/7.jpg","actividad_resources/media/8.jpg"],["0","0","0","0"],["0","0","0","0"]]; var xAnswer=5; answer=[]; rows=6; cols=10; xKey=-1; yKey=-1; animationX=[]; animationY=[]; animationPosX=[]; animationPosY=[]; animationLetter=[];
var words=[]; answers=[["Ferret","Turtle","Dolphin","Cat"],["Dog","Tiger","Spider","Ant"],["0","0","0","0"],["0","0","0","0"]]; letters=[]; indexLetters=0; xSel=-1; ySel=-1; iLetter=-1; jLetter=-1;
var alt1=[["FERRET","TURTLE","DOLPHIN","CAT"],["DOG","TIGER","SPIDER","ANT"],["0","0","0","0"],["0","0","0","0"]];
var alt2=[["ferret","turtle","dolphin","cat"],["dog","tiger","spider","ant"],["0","0","0","0"],["0","0","0","0"]];
var alt3=[["","","",""],["","","",""],["0","0","0","0"],["0","0","0","0"]];
var alt4=[["","","",""],["","","",""],["0","0","0","0"],["0","0","0","0"]];
var alt5=[["","","",""],["","","",""],["0","0","0","0"],["0","0","0","0"]];
var wordsGame="YWN0aXZpZGFk"; wordsStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
function giveZindex(typeElement){var valueZindex=0; capas=document.getElementsByTagName(typeElement);
for (i=0;i<capas.length;i++){if (parseInt($(capas[i]).css("z-index"),10)>valueZindex){valueZindex=parseInt($(capas[i]).css("z-index"),10);}}return valueZindex;}
var tiUD=true;
